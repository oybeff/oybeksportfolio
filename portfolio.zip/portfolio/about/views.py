from email.message import EmailMessage
from http.client import HTTPResponse
from unicodedata import name
from .models import Aside, Contack, Home, About, Skill, Teach, Service, Portfolio
from django.conf import settings
from django.shortcuts import render, redirect
from django.conf import settings
from about.forms import ContackForm
from urllib.request import urlopen 
import ssl
from django.template.loader import render_to_string
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse
from django.shortcuts import render

import ssl
ssl._create_default_https_context = ssl._create_unverified_context
# Create your views here.

def index(request):
    aside1 = Aside.objects.all()
    about1 = About.objects.all()
    about2 = About.objects.first()
    home1 = Home.objects.all()
    skill1 = Skill.objects.all()
    teach1 = Teach.objects.all() 
    teach2 = Teach.objects.last()
    portfolio = Portfolio.objects.first()
    portfolio1 = Portfolio.objects.exclude(main_title__isnull=True).exclude(main_title="").all()
    portfolio2 = Portfolio.objects.all()
    service = Service.objects.all()
    service1 = Service.objects.first()
    contack = Contack.objects.first()
    contack1 = Contack.objects.all()
    contack2 = Contack.objects.exclude(main_title__isnull=True).exclude(main_title="")
  
    if request.method == 'POST':
        form = ContackForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            subject = form.cleaned_data['subject']
            msg = form.cleaned_data['msg']
            
            html = render_to_string('about/base.html', {
                'name': name,
                'email': email,
                'subject': subject,
                'msg': msg,
            })
            send_mail(subject,  msg, email, recipient_list=['sobitovoybek69@gmail.com'])
            return redirect('home')
    else:
        form = ContackForm()
    
        context = {
        'aside1': aside1,
        'home1': home1,
        'about1': about1,
        'about2': about2,
        'skill1': skill1,
        'teach1': teach1,
        'teach2': teach2,
        'service': service,
        'service1': service1,
        'contack': contack,
        'contack1': contack1,
        'contack2': contack2,
        'form': form,
        'portfolio': portfolio,
        'portfolio1': portfolio1,
        'portfolio2': portfolio2
    }
    return render(request, 'about/index.html', context)


def about(request):
    return render(request, 'about/about.html')


# def send_email(request):
#     if request.method == "POST":
#         name = request.POST['Name']
#         email = request.POST['Email']
#         subject = request.POST['Subject']
#         msg = request.POST['Message']

#         something = EmailMessage(
#             f'Put msg {email}',
#             f'Name: {name}\n\n sendded msg: {msg}\n\n subject: {subject}n\n',
#             settings.EMAIL_HOST_USER,
#             [email]
#         )
#         email.fail_silenty = True
#         email.send()
#         return HTTPResponse('Successfully sended')
#     else:
#         return HTTPResponse('Unsuccess')