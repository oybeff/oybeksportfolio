from django.db import models
from django.contrib.auth.models import User
from django.template.defaultfilters import slugify

# Create your models here.


class Aside(models.Model):
    title = models.CharField('title', max_length=50)
    home = models.CharField('home', max_length=50)
    about = models.CharField('about', max_length=50)
    services = models.CharField('services', max_length=50)
    portfolio = models.CharField('portfolio', max_length=50, null=True, blank=True)
    contack = models.CharField('contack', max_length=50)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "aside"
        verbose_name_plural = "asides"

class Home(models.Model):
    title = models.CharField('title', max_length=50)
    name = models.CharField('name', max_length=50, null=True, blank=True)
    im = models.CharField("i'm", max_length=50)
    sub_title = models.TextField('sub title')
    cv = models.FileField(upload_to="cv")
    image = models.ImageField('image')
    score = models.IntegerField(default=80)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "home"
        verbose_name_plural = "homes"

class Skill(models.Model):
    name = models.CharField(max_length=20, blank=True, null=True)
    score = models.IntegerField(default=80, blank=True, null=True)
    is_key_skill = models.BooleanField(default=False)
    class_name = models.CharField(
        'class name', max_length=50, null=True, blank=True)

    def __str__(self):
        return self.name

class About(models.Model):
    title = models.CharField('title', max_length=50)
    name = models.CharField('name', max_length=50)
    sub_title = models.TextField('sub title')
    birthday = models.CharField('birthday', max_length=50)
    website = models.CharField('website', max_length=50)
    degree = models.CharField('degree', max_length=50)
    city = models.CharField('city', max_length=50)
    age = models.IntegerField('age')
    email = models.EmailField('email')
    phone = models.CharField('phone number', max_length=50)
    freelance = models.CharField('freelance', max_length=50)
    skills = models.ManyToManyField(Skill)
    teaching = models.CharField('teaching', max_length=60, null=True, blank=True)
    title2 = models.CharField('title2', max_length=50, null=True, blank=True)
    sub_title2 = models.TextField('sub_title2', null=True, blank=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "about"
        verbose_name_plural = "about"

class Teach(models.Model):

    teaching = models.CharField('teaching', max_length=60, null=True, blank=True)
    title2 = models.CharField('title2', max_length=50, null=True, blank=True)
    sub_title2 = models.TextField('sub_title2', null=True, blank=True)


    class Meta:
        verbose_name = "teach"
        verbose_name_plural = "teach"

class Service(models.Model):
    title = models.CharField('title', max_length=50, null=True, blank=True)
    main_title = models.CharField('main_title', max_length=50)
    description = models.TextField('description', max_length=50)
    class_name  = models.TextField('class name', max_length=50, null=True, blank=True)

    def __str__(self):
        return self.main_title

    class Meta:
        verbose_name = "service"
        verbose_name_plural = "services"

class Portfolio(models.Model):
    title = models.CharField('title', max_length=50, null=True, blank=True)
    main_title = models.CharField('main_title', max_length=50, null=True, blank=True)
    image = models.ImageField('image')


    class Meta:
        verbose_name = "portfolio"
        verbose_name_plural = "portfolios"

class Contack(models.Model):
    title = models.CharField('title', max_length=50, null=True, blank=True)
    main_title = models.CharField('main title', max_length=50, null=True, blank=True)
    sub_title = models.CharField('sub title', max_length=50, null=True, blank=True)
    class_name = models.CharField('class name', max_length=50)
    title2 = models.CharField('title2', max_length=50)
    main_title2 = models.CharField('main title2', max_length=50)
    title3 = models.CharField('title3', max_length=50, null=True, blank=True)
    main_title3 = models.CharField('main title3', max_length=50, null=True, blank=True)

    def __str__(self):
        return self.title2

    class Meta:
        verbose_name = "contack"
        verbose_name_plural = "contacks"