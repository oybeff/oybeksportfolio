from django.contrib import admin
from .models import About, Aside, Home, Skill, Teach, Service, Portfolio, Contack

# Register your models here.
admin.site.register(Aside)
admin.site.register(Home)
admin.site.register(About)
admin.site.register(Skill)
admin.site.register(Teach)
admin.site.register(Service)
admin.site.register(Portfolio)
admin.site.register(Contack)