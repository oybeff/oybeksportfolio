from unicodedata import name
from django import forms


class ContackForm(forms.Form):
    name = forms.CharField(label='name', required=False,
                             widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Name'}))
    email = forms.EmailField(label='email', required=False,
                             widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Email'}))
    subject = forms.CharField(label='subject', required=False,
                             widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Subject'}))
    msg = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Message'}))

    def __str__(self):
        return self.name